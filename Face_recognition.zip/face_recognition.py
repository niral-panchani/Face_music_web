# face_recognition.py
import cv2
from fer import FER

# Initialize the FER detector
detector = FER(mtcnn=True)  # you can set mtcnn=False if you want

def detect_mood_from_frame(frame):
    """
    Detect emotions in a single frame (numpy array)
    Returns the top emotion with its score
    """
    result = detector.detect_emotions(frame)
    if result:
        # FER returns a list of dictionaries, take the first face detected
        emotions = result[0]["emotions"]
        # Get the emotion with the highest score
        top_emotion = max(emotions, key=emotions.get)
        score = emotions[top_emotion]
        return top_emotion, score
    return None, None

def detect_mood_from_webcam():
    """
    Open webcam and detect emotions in real-time
    """
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Cannot open webcam")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        emotion, score = detect_mood_from_frame(frame)
        if emotion:
            cv2.putText(frame, f"{emotion} ({score:.2f})", (50, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        cv2.imshow("Mood Detection", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# Example usage
if __name__ == "__main__":
    detect_mood_from_webcam()
