async function loadCharts() {
  const response = await fetch("/mood_data");
  const data = await response.json();

  function renderChart(ctxId, dataset, title) {
    const ctx = document.getElementById(ctxId).getContext("2d");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: Object.keys(dataset),
        datasets: Object.keys(dataset[Object.keys(dataset)[0]] || {}).map(mood => ({
          label: mood,
          data: Object.keys(dataset).map(date => dataset[date][mood] || 0),
          backgroundColor: `hsl(${Math.random()*360},70%,60%)`
        }))
      },
      options: {
        responsive: true,
        plugins: {
          title: { display: true, text: title }
        }
      }
    });
  }

  renderChart("dailyChart", data.daily, "Daily Mood Distribution");
  renderChart("weeklyChart", data.weekly, "Weekly Mood Distribution");
  renderChart("monthlyChart", data.monthly, "Monthly Mood Distribution");
}

loadCharts();
