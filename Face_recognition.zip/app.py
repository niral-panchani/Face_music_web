from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_socketio import SocketIO
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import base64
import cv2
import os
import numpy as np
from deepface import DeepFace
import requests
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "secretkey"
socketio = SocketIO(app, cors_allowed_origins="*")
DATABASE = "face_music.db"

# --- API keys ---
JAMENDO_CLIENT_ID = "38e2ebee"
SPOTIFY_CLIENT_ID = "d722ed6061ce463d85ea0eaa2ebba329"
SPOTIFY_CLIENT_SECRET = "8bb96ab66b6345dbab867b6db3db250b"

# Spotify client
spotify_client = spotipy.Spotify(auth_manager=SpotifyClientCredentials(
    client_id=SPOTIFY_CLIENT_ID,
    client_secret=SPOTIFY_CLIENT_SECRET
))

# --- Mood mapping and tips ---
mood_map = {
    "happy": "happy",
    "angry": "angry",
    "sad": "sad",
    "neutral": "chill",
    "surprise": "pop",
    "fear": "relax",
    "disgust": "classical"
}

tips_dict = {
    "happy": "Keep spreading positivity! Maintain gratitude.",
    "sad": "Take a short walk, listen to uplifting music, or talk to a friend.",
    "angry": "Try deep breathing or step away from stressful situations.",
    "neutral": "Stay mindful and relaxed.",
    "surprise": "Embrace new opportunities and stay curious.",
    "fear": "Practice calming techniques or positive affirmations.",
    "disgust": "Focus on something pleasant and take a break."
}

# ---------- Database ----------
def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# ---------- Mood Detection ----------
def detect_mood_from_frame(frame_b64):
    try:
        img_bytes = base64.b64decode(frame_b64.split(",")[1])
        nparr = np.frombuffer(img_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        img = cv2.resize(img, (0,0), fx=0.5, fy=0.5)
        result = DeepFace.analyze(img, actions=['emotion'], enforce_detection=False)
        return result[0]['dominant_emotion']
    except Exception as e:
        print("Emotion detection error:", e)
        return "neutral"

# ---------- Routes ----------
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        conn = get_db_connection()
        try:
            conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            flash("Registration successful. Please log in.", "success")
            return redirect(url_for("login"))
        except:
            flash("Username already exists!", "danger")
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        conn.close()
        if user and user["password"] == password:
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            flash("Login successful!", "success")
            return redirect(url_for("home"))
        else:
            flash("Invalid credentials", "danger")
    # No flash here unless POST failed
    return render_template("login.html")

@app.route("/profile")
def profile():
    if "user_id" not in session:
        return redirect(url_for("login"))
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    conn.close()
    return render_template("profile.html", user=user)


UPLOAD_FOLDER = os.path.join("static", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/update_profile", methods=["POST"])
def update_profile():
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db_connection()
    cursor = conn.cursor()
    user_id = session["user_id"]

    username = request.form.get("username")
    password = request.form.get("password")
    file = request.files.get("profile_pic")

    # Fetch current user profile
    cursor.execute("SELECT profile_pic FROM users WHERE id=?", (user_id,))
    row = cursor.fetchone()
    current_pic = row["profile_pic"] if row else None

    # Handle image upload
    profile_pic_path = current_pic  # default (keep old image if no new one)
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
        file.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))
        profile_pic_path = f"uploads/{filename}"  # save relative to static/

    # Update user info
    cursor.execute("""
        UPDATE users
        SET username=?, password=?, profile_pic=?
        WHERE id=?
    """, (username, password, profile_pic_path, user_id))

    conn.commit()
    conn.close()

    flash("✅ Profile updated successfully!", "success")
    return redirect(url_for("profile"))



@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/privacy')
def privacy():
    return render_template('privacy.html')

@app.route("/home")
def home():
    if "user_id" not in session:
        return redirect(url_for("login"))
    last_tip = session.get("last_tip", "Stay positive and keep smiling!")
    return render_template("home.html", username=session["username"], last_tip=last_tip)

@app.route("/player/<mood>")
def player(mood):
    if "user_id" not in session:
        return redirect(url_for("login"))

    query = mood_map.get(mood.lower(), "chill")

    jamendo_url = f"https://api.jamendo.com/v3.0/tracks/?client_id={JAMENDO_CLIENT_ID}&format=json&limit=10&fuzzytags={query}"
    res = requests.get(jamendo_url).json()
    tracks = []
    if res.get("results"):
        for t in res["results"]:
            tracks.append({
                "name": t["name"],
                "artist": t["artist_name"],
                "audio": t["audio"],
                "image": t["album_image"],
            })

    spotify_tracks = []
    try:
        playlist_results = spotify_client.search(q=f"{query} playlist", type="playlist", limit=1)
        if playlist_results['playlists']['items']:
            playlist_id = playlist_results['playlists']['items'][0]['id']
            tracks_res = spotify_client.playlist_tracks(playlist_id, limit=10)
            for item in tracks_res['items']:
                track = item['track']
                spotify_tracks.append({
                    "name": track['name'],
                    "artist": ", ".join([a['name'] for a in track['artists']]),
                    "link": track['external_urls']['spotify'],
                    "image": track['album']['images'][0]['url'] if track['album']['images'] else ""
                })
    except Exception as e:
        print("Spotify API error:", e)

    conn = get_db_connection()
    conn.execute("INSERT INTO moods (user_id, mood, timestamp) VALUES (?, ?, ?)",
                 (session["user_id"], mood, datetime.now()))
    conn.commit()
    conn.close()

    return render_template("player.html", tracks=tracks, mood=mood, spotify_tracks=spotify_tracks)

@app.route("/moodboard")
def moodboard():
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db_connection()
    today = datetime.now().date()
    week_ago = datetime.now() - timedelta(days=7)
    month_ago = datetime.now() - timedelta(days=30)

    daily_data = [dict(row) for row in conn.execute("""
        SELECT mood, COUNT(*) as count
        FROM moods
        WHERE user_id=? AND DATE(timestamp)=?
        GROUP BY mood
    """, (session["user_id"], today)).fetchall()]

    weekly_data = [dict(row) for row in conn.execute("""
        SELECT mood, COUNT(*) as count
        FROM moods
        WHERE user_id=? AND timestamp>=?
        GROUP BY mood
    """, (session["user_id"], week_ago)).fetchall()]

    monthly_data = [dict(row) for row in conn.execute("""
        SELECT mood, COUNT(*) as count
        FROM moods
        WHERE user_id=? AND timestamp>=?
        GROUP BY mood
    """, (session["user_id"], month_ago)).fetchall()]

    conn.close()
    return render_template("moodboard.html",
                           daily=daily_data,
                           weekly=weekly_data,
                           monthly=monthly_data,
                           tips=tips_dict)

# ---------- SocketIO ----------
last_mood = {}

@socketio.on("frame")
def handle_frame(data):
    user_id = session.get("user_id")
    if not user_id:
        return
    frame_b64 = data.get("frame")
    mood_detected = detect_mood_from_frame(frame_b64)
    last_mood[user_id] = mood_detected
    session["last_tip"] = tips_dict.get(mood_detected.lower(), "Stay positive and keep smiling!")
    socketio.emit("frame_response", {"mood": mood_detected, "tip": session["last_tip"]}, room=request.sid)

if __name__ == "__main__":
    socketio.run(app, debug=True)
