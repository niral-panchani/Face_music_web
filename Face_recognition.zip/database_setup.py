import sqlite3

# Connect (this will create face_music.db if it doesn't exist)
conn = sqlite3.connect("face_music.db")
c = conn.cursor()

# Drop old users table if you want to reset it completely (optional)
# ⚠️ This will delete all previous user data!
# c.execute("DROP TABLE IF EXISTS users")

# Users table with profile picture
c.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    profile_pic TEXT DEFAULT ''
)
""")

# Moods table
c.execute("""
CREATE TABLE IF NOT EXISTS moods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    mood TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
)
""")

conn.commit()
conn.close()

print("✅ Database setup completed with profile picture field.")
